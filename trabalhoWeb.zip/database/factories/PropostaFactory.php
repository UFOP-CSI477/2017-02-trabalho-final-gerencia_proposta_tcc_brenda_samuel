<?php

use Faker\Generator as Faker;

$factory->define(App\Proposta::class, function (Faker $faker) {
    return [
        //
    ];
});
