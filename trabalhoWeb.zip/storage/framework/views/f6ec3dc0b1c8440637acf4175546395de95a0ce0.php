<?php $__env->startSection('content'); ?>


    <hgroup>
        <h1>Gerência de propostas de TCC</h1>
        <h3>Por favor efetue o login para utilizar o sistema:</h3>
    </hgroup>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-body">
                    
                        

                        
                            

                            
                                

                                
                                    
                                        
                                    
                                
                            
                        

                        
                            

                            
                                

                                
                                    
                                        
                                    
                                
                            
                        

                        
                            
                                
                                    
                                        
                                    
                                
                            
                        

                        
                            
                                
                                    
                                

                                

                            
                        
                    


                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="group">
                            <input type="email" name="email"><span class="highlight"></span><span class="bar"></span>
                            <label>Email</label>
                        </div>



                        <div class="group">
                            <input type="password" name="password"><span class="highlight"></span><span class="bar"></span>
                            <label>Password</label>

                        </div>




                        <button type="submit" class="button buttonBlue">Login
                            <div class="ripples buttonRipples"><span class="ripplesCircle"></span></div>
                        </button>
                    </form>
                    <footer>
                        <a href="http://www.ufop.br"><img src="img/logo.png"></a>
                        <p>  <a href="http://www.ufop.br" target="_blank">Ufop</a> 2018</p>
                    </footer>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.empty', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>