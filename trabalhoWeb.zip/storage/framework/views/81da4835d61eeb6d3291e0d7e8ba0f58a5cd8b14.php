<?php $__env->startSection('active4'); ?>
    active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div style="">
        <div  class="center-block" >
            <h3>Nome:</h3>
            <p class="lead">
                <?php echo e($proposta[0]->nomealuno); ?>

            </p>
            <h3>Matricula:</h3>
            <p class="lead"><?php echo e($proposta[0]->matricula); ?>

            </p>
            <h3>Orientação</h3>
            <p class="lead">
                <?php echo e($proposta[0]->orientador); ?>

                </br><?php echo e($proposta[0]->coorientador); ?>

            </p>


            <h3>Disciplina:</h3>
            <p class="lead">
                <?php if($proposta[0]->tipotcc==1): ?>
                    TCC1
                <?php else: ?>
                    TCC2
                <?php endif; ?>
            </p>
            <h3>Titulo:</h3>
            <p class="lead">
                <?php echo e($proposta[0]->titulo); ?>

            </p>
            <h3>Tema:</h3>
            <p class="lead">
                <?php echo e($proposta[0]->tema); ?>

            </p>
            <h3>Objetivos:</h3>
            <p class="lead">
                <?php echo e($proposta[0]->objetivos); ?>

            </p>

            <h3>Descrição do Problema:</h3>
            <p class="lead">

                <?php echo e($proposta[0]->problema); ?>

            </p>

            <h3>Referencias:</h3>
            <p class="lead">
                <?php echo e($proposta[0]->referencias); ?>


            </p>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.empty', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>