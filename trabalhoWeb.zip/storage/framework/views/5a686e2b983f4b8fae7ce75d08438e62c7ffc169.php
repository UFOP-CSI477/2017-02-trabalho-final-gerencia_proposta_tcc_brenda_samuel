<?php $__env->startSection('active2'); ?>
    active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <table class="table">
        <tr>
            <th>Nome Aluno</th>
            <th>Titulo do Trabalho</th>
            <th>Orientador</th>
            <th>Data de solicitação</th>
            <th>Visualizar/Aprovar Proposta </th>>
        </tr>

        <?php $__currentLoopData = $propostas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($proposta->nomealuno); ?></td>
                <td><?php echo e($proposta->titulo); ?></td>
                <td><?php echo e($proposta->orientador); ?></td>
                <td><?php echo e($proposta->created_at); ?></td>
                <td><div class="form-horizontal form-group">
                        <a class="button btn btn-success" href="<?php echo e(url('aprovarproposta/'.$proposta->id)); ?>"}> Aprovar Proposta </a>
                        <a class="button btn btn-warning" target="_blank" href="<?php echo e(url('verproposta/'.$proposta->id)); ?>"> Visualizar Proposta </a>


                    </div></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>